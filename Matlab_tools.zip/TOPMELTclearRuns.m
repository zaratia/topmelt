function TOPMELTclearRuns(varargin)
% Function to delete data of RUNS from MySQL
% INPUT: 
%   - ODBC
%   - Run from: First (or only) run to delete
%   - (optional) Run To: last run to delete

narginchk(2,3);
nargoutchk(0,0);

ODBC = varargin{1};
idrunFrom = varargin{2};
if nargin > 2
    idrunTo = varargin{3};
else
    idrunTo = idrunFrom;
end

conn1 = database(ODBC, 'pantarhei', 'arffs');

for iR = idrunFrom:idrunTo
    %delete data from all tables
    curs = exec(conn1, ['delete from  input_t where idrun = ' num2str(iR)]);
    curs = exec(conn1, ['delete from  input_p where idrun = ' num2str(iR)]);    
    curs = exec(conn1, ['delete from  snowinitvar where idrun = ' num2str(iR)]);
    curs = exec(conn1, ['delete from  rasweresults where idrun = ' num2str(iR)]);
    curs = exec(conn1, ['delete from  runs where idrun = ' num2str(iR)]);
    curs = exec(conn1, ['delete from  snowdates where idrun = ' num2str(iR)]);
    curs = exec(conn1, ['delete from  snowresults where idrun = ' num2str(iR)]);
    curs = exec(conn1, ['delete from  snowstatevar where idrun = ' num2str(iR)]);
end
end