%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% WARNING ELEVBNDS, ENERGYBNDS, EICORR TABLES WILL BE DELETED BEFORE RE-POPULATION %
% ONLY BASINS IN THE RASTER MASK WILL BE DELETED                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% INPUT
inPath = '.\Rasters\'; % where dem and basin rasters are stored
enPath = '.\W4\'; % where energy maps are stored
nBands = 18; % elevation bands
bandAmp = 200; % band amplitude
nClasses = 10; % energy bands
sPix = 30; % pixel size m
nMaps = 12; % number of maps
idelevbnd = 1; % starting elevbnd ID
idenergybnd=1; % starting energybnd ID
nrows = 1980; % number of rows in ASCII file
ncols = 2138; % number of cols in ASCII file
matrext = [6 0 nrows+5 ncols-1]; % info to extract the matrix from the raster 
                          % [header_rows 0 nrows-1 ncols-1]
MASK_TOT = dlmread([inPath,'aurinoBASIN.asc'],'',matrext); % load basin mask
DEM = dlmread([inPath,'aurinoDEM.asc'],'',matrext); % load DEM 
GLA = dlmread([inPath,'aurinoGLAC.asc'],'',matrext); % load Glacier area
conn = database('aurino','root','arffs'); % mysql connection info

%% OUTPUT
% AVGEI.mat:    matrix with averaged Energy Index
% CLASSES.mat:  matrix of energy classes distribution for EI each map
% Writes ENERGYBNDS and ELEVBNDS tables. !!!DELETE!!! end then rewrites

%% POPOLADB 

idbasinVec = unique(MASK_TOT(MASK_TOT>=0)); % vector with basin ID

for bas = 1:size(idbasinVec) % clear tables, only for basins in the mask
    idbasin = idbasinVec(bas);
    sqlstr = ['DELETE FROM ELEVBNDS WHERE IDBASIN =',int2str(idbasin)];
    tmp = exec(conn,sqlstr);
    sqlstr = ['DELETE FROM ENERGYBNDS WHERE IDBASIN =',int2str(idbasin)];
    tmp = exec(conn,sqlstr);
    sqlstr = ['DELETE FROM EICORR WHERE IDBASIN =',num2str(idbasin)];
    tmp = exec(conn,sqlstr);
end

for bas = 1:size(idbasinVec)    
    idbasin = idbasinVec(bas);
    MASK = (MASK_TOT==idbasin);
    disp(['Basin ',num2str(idbasin),': populating elevation bands and energy classes...']);

    for id = 1:nMaps

        EI = dlmread([enPath,num2str(id),'.asc'],'',matrext); % load map  
        EI = EI.*MASK;

        nr = size(EI,1); nc=size(EI,2);
        Bands = zeros(nr,nc);

        maxVal = round(nr*nc/10); % maximum values, should be nr*nc

        for i=1:nBands
            Bands(DEM<=i*bandAmp & DEM>(i-1)*bandAmp) = i;
        end

        EV = zeros(nBands,maxVal);
        sizeBand = zeros(nBands,1);
        EIb=zeros(nBands,nr,nc);
        for b=1:nBands         
            tmp = EI .* (Bands == b);
            EIb(b,:,:) = tmp; % band b
            Sorted = sort(tmp(tmp>0));
            sizeBand(b) = size(Sorted,1);
            EV(b,1:size(Sorted,1)) = Sorted; % sort values of b band
            EV(b,size(Sorted,1)+1:maxVal) = 1000; % add one very big data
        end

        AVGEI{id} = zeros(nBands,nClasses); % energy that will be in energybnds
        area = zeros(nBands,nClasses); % area of each energy band
        areagla = zeros(nBands,nClasses); % glacier area
        CLASSES{id} = zeros(nr,nc); % matrix of classes
        CLASSES{id}(:,:) = -9999;

        for b = 1:nBands     
            for r = 1:nr
                for c =1:nc
                    if EIb(b,r,c)>0 % if not external            
                        for i=1:nClasses                    
                            thrInf = round(double(sizeBand(b))/double(nClasses) * double(i-1) + 1.0);
                            thrSup = round(double(sizeBand(b))/double(nClasses) * double(i) + 1.0);
                            if ((EIb(b,r,c)>=EV(b,thrInf)) && (EIb(b,r,c)<EV(b,thrSup))) 
                                AVGEI{id}(b,i) = AVGEI{id}(b,i) + EIb(b,r,c);
                                area(b,i) = area(b,i) + 1;
                                CLASSES{id}(r,c) = i;
                                if GLA(r,c)>=0
                                    areagla(b,i) = areagla(b,i) + 1;
                                end
                            end                        
                        end
                    end      
                end
            end
        end

        for b=1:nBands 
            for c=1:nClasses
                AVGEI{id}(b,c) = AVGEI{id}(b,c) / area(b,c); 
                area(b,c) = area(b,c) * sPix * sPix;     
                areagla(b,c) = areagla(b,c) * sPix * sPix;   
            end
        end

       % AVGEI{id} = AVGen; % storing average energy for each class

    end
    % write energybnds table
    for id = 1:nMaps  
        idelevbnd2 = idelevbnd;   
        for b = 1:nBands % write energybnds table         
            for c = 1:nClasses
                if area(b,c)==0    
                    sqlstr = ['INSERT INTO ENERGYBNDS(id,idelevbnd,ideimap,idbasin,percentile,minenergy,avgenergy,area,glacier_area) VALUES (',...
                            num2str(idenergybnd),',',num2str(idelevbnd2),',',num2str(id),',',num2str(idbasin),',',...
                            num2str(c/nClasses),',',num2str(-999.9),',',num2str(-999.9),',',num2str(area(b,c)),',',num2str(areagla(b,c)),')'];
                    idenergybnd = idenergybnd + 1;
                    tmp = exec(conn,sqlstr);
                else
                    sqlstr = ['INSERT INTO ENERGYBNDS(id,idelevbnd,ideimap,idbasin,percentile,minenergy,avgenergy,area,glacier_area) VALUES (',...
                            num2str(idenergybnd),',',num2str(idelevbnd2),',',num2str(id),',',num2str(idbasin),',',...
                            num2str(c/nClasses),',',num2str(1),',',num2str(AVGEI{id}(b,c)),',',num2str(area(b,c)),',',num2str(areagla(b,c)),')'];
                    idenergybnd = idenergybnd + 1;
                    tmp = exec(conn,sqlstr);
                end
            end            
            idelevbnd2 = idelevbnd2 + 1;
        end
    end
    % write elevbnds table
    for b=1:nBands % write elevbnds table    
        sqlstr = ['INSERT INTO ELEVBNDS(id,idbasin,elevfrom,elevto,area) VALUES (',num2str(idelevbnd),',',...
                    num2str(idbasin),',',num2str((b-1)*bandAmp),',',num2str(b*bandAmp),',',num2str(sum(area(b,1:nClasses))),')'];
        tmp = exec(conn,sqlstr);
        idelevbnd = idelevbnd + 1;
    end

    % write basins area and average quote
    sqlstr = ['UPDATE BASINS SET AREA = (SELECT SUM(AREA) FROM ELEVBNDS WHERE IDBASIN = ',int2str(idbasin),') WHERE ID = ',int2str(idbasin)];
    tmp = exec(conn,sqlstr);
    sqlstr = ['UPDATE BASINS SET AVGQUOTE = (SELECT SUM(AREA * (ELEVFROM/2+ELEVTO/2) ) / SUM(AREA) FROM ELEVBNDS WHERE IDBASIN = ',int2str(idbasin),') WHERE ID = ',int2str(idbasin)];
    tmp = exec(conn,sqlstr);

    save CLASSES CLASSES
    save AVGEI AVGEI

    %% Popola EI correction
    
    disp(['Basin ',num2str(idbasin),': populating correction coefficients...'])
    nr = size(DEM,1); nc=size(DEM,2);
    Bands = zeros(nr,nc);

    % starting energybnd ID in table EICORR: MUST BE THE SAME AS ENERGYBND!!!
    sqlstr = ['SELECT ID FROM ENERGYBNDS WHERE IDBASIN = ', num2str(idbasin),...
        ' ORDER BY ID LIMIT 1'];
    idenergybnd = cell2mat(fetch(conn,sqlstr)); 

    sqlstr = ['SELECT ID FROM ELEVBNDS WHERE IDBASIN = ', num2str(idbasin),...
        ' ORDER BY ID LIMIT 1'];
    idelevbnd = cell2mat(fetch(conn,sqlstr)); 

    for b=1:nBands % Build elevbnds matrix
        Bands(DEM<=b*bandAmp & DEM>(b-1)*bandAmp) = b;
    end

    for id = 1:nMaps

        MIGR{id} = zeros(nBands,nClasses,nClasses);
        %check = zeros(nClasses,nClasses);
        for b=1:nBands % Build elevbnds matrix
            tmp1 = (Bands==b);    
            if sum(tmp1(:))>0 % the band is not empty
                for ca=1:nClasses % ca source class
                    for cb=1:nClasses % cn destination class
                        if id < nMaps
                            tmpa = (CLASSES{id}==ca).*tmp1;
                            tmpb = (CLASSES{id+1}==cb).*tmp1;
                        else % id = nMaps
                            tmpa = (CLASSES{id}==ca).*tmp1;
                            tmpb = (CLASSES{1}==cb).*tmp1;
                        end
                        tmp = tmpa .* tmpb; % this are the pixels 
                        % MIGR(i,j) are the pixels that moved from class j to i
                        MIGR{id}(b,cb,ca) = sum(tmp(:)); % pixels from class ca to class cb  
                        %check(cb,ca) = sum(tmp(:));
                    end              
                end
            end
        end
        %check = zeros(nClasses,nClasses);
        EICorr{id} = zeros(nBands,nClasses,nClasses);
        for b=1:nBands % estimate correction coefficients      
            for ca=1:nClasses
                for cb=1:nClasses
                    if sum(MIGR{id}(b,cb,:))>0 % if we have migration to cb
                        EICorr{id}(b,cb,ca) = MIGR{id}(b,cb,ca)/sum(MIGR{id}(b,cb,:));
                    end
                end
            end
        end
    end
    
    save EICorr EICorr
    % write EIcorr table
    sqlstr = ['DELETE FROM EICORR WHERE IDBASIN =',num2str(idbasin)];
    tmp = exec(conn,sqlstr);
    for id = 1:nMaps           
        idelevbnd2 = idelevbnd;
        for b=1:nBands % write EICORR   
            for ca=1:nClasses
                for cb=1:nClasses                    
                        sqlstr =['insert into EIcorr(idelevbnd,idenergybnd,ideimap,idbasin,percfrom,percto,EIcorr) values(',...
                            num2str(idelevbnd2),',',num2str(idenergybnd),',',num2str(id),',',num2str(idbasin),',',num2str(ca/nClasses),',',num2str(cb/nClasses),',',...
                            num2str(EICorr{id}(b,cb,ca)),')'];                        
                        tmp = exec(conn,sqlstr);
                end
                idenergybnd = idenergybnd + 1;    
            end                                    
            idelevbnd2 = idelevbnd2 + 1;
        end
    end
    % starting ELEVBNDS ID in table ELEVBNDS FOR NEXT BASIN
    sqlstr = ['SELECT MAX(ID)+1 FROM ELEVBNDS WHERE IDBASIN = ',...
        num2str(idbasin)];
    idelevbnd = cell2mat(fetch(conn,sqlstr)); 
    % starting ENERGYBNDS ID in table ENERGYBNDS FOR NEXT BASIN
    sqlstr = ['SELECT MAX(ID)+1 FROM ENERGYBNDS WHERE IDBASIN = ',...
        num2str(idbasin)];
    idenergybnd = cell2mat(fetch(conn,sqlstr));
end % basins

clearvars
